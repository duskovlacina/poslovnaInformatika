package com.poslovna.market;



import java.math.BigInteger;
import java.text.ParseException;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.poslovna.market.models.Artikal;
import com.poslovna.market.models.BusinessPartner;
import com.poslovna.market.models.Company;
import com.poslovna.market.models.JedinicaMere;
import com.poslovna.market.models.Korisnik;
import com.poslovna.market.models.Korisnik.Role;
import com.poslovna.market.repositories.JedinicaMereRepository;
import com.poslovna.market.services.ArtikalService;
import com.poslovna.market.services.BusinessPartnerService;
import com.poslovna.market.services.CompanyService;
import com.poslovna.market.services.UserService;

@Component
public class ProjectTestData {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private BusinessPartnerService partnerService;
	
	@Autowired
	private ArtikalService artikalService;
	
	@Autowired
	private JedinicaMereRepository jedinicaMereRepository;
	
	
	@PostConstruct
	private void init() throws ParseException{
		
		if(userService.findAll().size() == 0) {
			
			
			String address="bb";
			String bank="Intesa";
			String phonenumber="066 50556 0656";
			Integer activitycode=4545456;
			BigInteger cidnumber=BigInteger.valueOf(456456);
			String account="customer";
			String email="test@yahoo.com";
			String name="testname";
			BigInteger pib=BigInteger.valueOf(46546);
			
			Company kompanija = new Company(name, pib, address, phonenumber, cidnumber, activitycode, email, account, bank);
			companyService.add(kompanija);
			
			Korisnik korisnik = new Korisnik("admin", "admin", Role.ADMIN,kompanija);
			userService.save(korisnik);
			
			BusinessPartner bp1 = new BusinessPartner();
			bp1.setCompany1(kompanija);
			bp1.setCompany2(kompanija);
			partnerService.save(bp1);
			
//			Artikal artikal = new Artikal("1", "Lap Top", "Lap top za posao", "vrsta");
//			artikalService.saveArtikal(artikal);
//			
//			JedinicaMere jedinicaMere = new JedinicaMere("Oznaka jedinice mere", "Naziv jedinice mere");
//			jedinicaMereRepository.save(jedinicaMere);
			
	
		}			
			
	}

}
